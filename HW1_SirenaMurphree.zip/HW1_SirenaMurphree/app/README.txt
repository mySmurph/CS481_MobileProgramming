Name:	Sirena Murphree
Email:	murph135@cougars.csusm.edu
App:	HW1_SirenaMurphree.app

Tested using AVD Pixel XL API 30 running Android 11.0 x86