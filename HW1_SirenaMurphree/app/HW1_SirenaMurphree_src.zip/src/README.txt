Name:	Sirena Murphree
Email:	murph135@cougars.csusm.edu
App:	HW1_SirenaMurphree.app

Tested using AVD Pixel XL API 30 running Android 11.0 x86

Google drive:
https://drive.google.com/file/d/1E9FtyBvD2aoFQFU4sxQ1w_C4qWOyhbeq/view?usp=sharing